package xyz.notheartyt.easytp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class EasyTP {
    public static final String MOD_ID = "easy_tp";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private EasyTP() {
    }
}
