package xyz.notheartyt.easytp;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class TeleportScreen extends Screen {
    public TeleportScreen() {
        super(Text.literal("Teleport"));
    }

    @Override
    protected void init() {
        int x = width / 2 - 115;
        int y = height / 2 - 32;

        addDrawableChild(ButtonWidget.builder(Text.literal("Bring selected player to me"), button -> {
            runCommand("tp " + PlayersScreen.getSelectedPlayer() + " @s");
        }).dimensions(x, y, 230, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Teleport me to selected player"), button -> {
            runCommand("tp @s " + PlayersScreen.getSelectedPlayer());
        }).dimensions(x, y + 26, 230, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Back"), button -> {
            if (client != null) client.setScreen(new DashboardScreen());
        }).dimensions(x, y + 62, 230, 20).build());
    }

    private void runCommand(String command) {
        if (client == null || client.player == null || client.getNetworkHandler() == null) return;

        String selected = PlayersScreen.getSelectedPlayer();
        if (selected == null || selected.isBlank()) {
            client.player.sendMessage(Text.literal("Select a player first."), false);
            return;
        }

        client.getNetworkHandler().sendChatCommand(command);
        client.player.sendMessage(
            Text.literal("Teleport command sent. The server must allow you to use /tp."),
            false
        );
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 30, 0xFFFFFF);
        context.drawCenteredTextWithShadow(
            textRenderer,
            Text.literal("Requires OP permission or cheats enabled."),
            width / 2, 48, 0xFFCC66
        );
        context.drawCenteredTextWithShadow(
            textRenderer,
            Text.literal("Commands are sent normally; this mod does not bypass server permissions."),
            width / 2, 62, 0xB8C7D9
        );
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
