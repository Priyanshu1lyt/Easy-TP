package xyz.notheartyt.easytp;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public final class EasyTPClient implements ClientModInitializer {
    private static KeyBinding openDashboardKey;

    @Override
    public void onInitializeClient() {
        openDashboardKey = KeyBindingHelper.registerKeyBinding(
            new KeyBinding(
                "key.easy_tp.open_dashboard",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_P,
                KeyBinding.Category.create(Identifier.of("easy_tp", "main"))
            )
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openDashboardKey.wasPressed()) {
                if (client.player != null) {
                    client.setScreen(new DashboardScreen());
                }
            }
        });

        EasyTP.LOGGER.info("Easy TP client initialized.");
    }
}
