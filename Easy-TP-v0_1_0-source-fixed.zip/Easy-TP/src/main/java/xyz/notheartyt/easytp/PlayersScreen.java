package xyz.notheartyt.easytp;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class PlayersScreen extends Screen {
    private static String selectedPlayer;

    public PlayersScreen() {
        super(Text.literal("Online Players"));
    }

    public static String getSelectedPlayer() {
        return selectedPlayer;
    }

    @Override
    protected void init() {
        int left = width / 2 - 105;
        int y = 55;
        List<String> names = new ArrayList<>();

        if (client != null && client.getNetworkHandler() != null) {
            for (PlayerListEntry entry : client.getNetworkHandler().getPlayerList()) {
                names.add(entry.getProfile().name());
            }
        }
        names.sort(Comparator.naturalOrder());

        if (names.isEmpty()) {
            addDrawableChild(ButtonWidget.builder(Text.literal("No player list available"), b -> {})
                .dimensions(left, y, 210, 20).build());
        } else {
            int shown = Math.min(names.size(), 8);
            for (int i = 0; i < shown; i++) {
                String name = names.get(i);
                String label = name.equals(selectedPlayer) ? "✓ " + name : name;
                addDrawableChild(ButtonWidget.builder(Text.literal(label), button -> {
                    selectedPlayer = name;
                    if (client != null) client.setScreen(new PlayersScreen());
                }).dimensions(left, y + i * 24, 210, 20).build());
            }
            if (names.size() > shown) {
                addDrawableChild(ButtonWidget.builder(
                    Text.literal("Showing first 8 of " + names.size()), b -> {})
                    .dimensions(left, y + shown * 24, 210, 20).build());
            }
        }

        addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> {
            if (client != null) client.setScreen(new DashboardScreen());
        }).dimensions(left, height - 32, 100, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Teleport options"), b -> {
            if (client != null) client.setScreen(new TeleportScreen());
        }).dimensions(left + 110, height - 32, 100, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 25, 0xFFFFFF);
        context.drawCenteredTextWithShadow(
            textRenderer,
            Text.literal("Selected: " + (selectedPlayer == null ? "None" : selectedPlayer)),
            width / 2, 40, 0xB8C7D9
        );
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
