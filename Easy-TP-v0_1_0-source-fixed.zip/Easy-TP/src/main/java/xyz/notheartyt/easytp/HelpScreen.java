package xyz.notheartyt.easytp;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class HelpScreen extends Screen {
    public HelpScreen() {
        super(Text.literal("Easy TP Help"));
    }

    @Override
    protected void init() {
        addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> {
            if (client != null) client.setScreen(new DashboardScreen());
        }).dimensions(width / 2 - 50, height - 35, 100, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 30, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Press P to open the dashboard."), width / 2, 62, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Choose a player, then open Teleport options."), width / 2, 80, 0xB8C7D9);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Teleport works only when the server grants command permission."), width / 2, 98, 0xFFCC66);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
