package xyz.notheartyt.easytp;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class DashboardScreen extends Screen {
    public DashboardScreen() {
        super(Text.literal("Easy TP"));
    }

    @Override
    protected void init() {
        int buttonWidth = 190;
        int x = (this.width - buttonWidth) / 2;
        int y = this.height / 2 - 45;

        addDrawableChild(ButtonWidget.builder(Text.literal("Players"), button -> {
            if (client != null) client.setScreen(new PlayersScreen());
        }).dimensions(x, y, buttonWidth, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Teleport"), button -> {
            if (client != null) client.setScreen(new TeleportScreen());
        }).dimensions(x, y + 26, buttonWidth, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("About / Help"), button -> {
            if (client != null) client.setScreen(new HelpScreen());
        }).dimensions(x, y + 52, buttonWidth, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), button -> close())
            .dimensions(x, y + 78, buttonWidth, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 28, 0xFFFFFF);
        context.drawCenteredTextWithShadow(
            textRenderer,
            Text.literal("Client-side server management menu"),
            width / 2, 43, 0xB8C7D9
        );
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
