# Easy TP

A client-side Fabric mod for Minecraft Java 1.21.11 by NotHeartYT.

## Current v0.1.0 features
- Press **P** to open the dashboard.
- View the online player list.
- Select a player.
- Send normal `/tp` commands to bring the selected player to you or teleport yourself to them.
- GitHub Actions workflow builds the mod JAR.

## Requirements
- Minecraft Java 1.21.11
- Java 21
- Fabric Loader
- Fabric API

## Build
Install Gradle 9.2.1 or a compatible Gradle 9.x version, then run:

```bash
gradle build
```

The JAR will be created in `build/libs/`.

## Important
This is a client-side interface. Teleport commands are sent through the normal Minecraft command channel. You must have OP permission or cheats enabled. The mod does not bypass server permissions.

## Planned
- Persistent colour-coded teams
- Team assignment and management
- Coordinate and dimension teleport UI
- Confirmation/results screen
- Search and pagination for large player lists

## Repository
https://github.com/Priyanshu1lyt/Easy-TP
